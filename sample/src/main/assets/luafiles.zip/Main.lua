require("config")
require("framework.init")

--主入口函数。从这里开始lua逻辑
function Main()
print("-----------main111111111------------");
end

function excute( filename , gameObject)
 	local cls = require("app.modules." .. filename .. "." .. filename)
	assert(cls, string.format("Class [%s] not found. Please check.", filename))
	if cls then
		cls.new(gameObject)
	end
	-- UpdateBeat:Add(function(sender)
	-- 	print("-----------main------------");
	-- end, self)
end

function destory()
	-- delete（）
	print("-----------destory------------");
end

--场景切换通知
function OnLevelWasLoaded(level)
	print("==== OnLevelWasLoaded ====")
	Time.timeSinceLevelLoad = 0
end

local status, msg = xpcall(Main, __G__TRACKBACK__)
if not status then
    print(msg)
end