--
-- Author: Sowyer(e-mail:suyang@loveorange.com)
-- Date: 2016-12-02 17:52:47
--
ul = {} -- global unity lua framework

require("framework.common.functions")
require("framework.package_support")

-- register components
ul.register("event", require("framework.components.event"))
