-- Unity-Lua core functions
ul.loaded_packages = {}
local loaded_packages = ul.loaded_packages

function ul.register(name, package)
    ul.loaded_packages[name] = package
end

function ul.load(...)
    local names = {...}
    assert(#names > 0, "ul.load() - invalid package names")

    local packages = {}
    for _, name in ipairs(names) do
        assert(type(name) == "string", string.format("ul.load() - invalid package name \"%s\"", tostring(name)))
        if not loaded_packages[name] then
            local packageName = string.format("packages.%s.init", name)
            local cls = require(packageName)
            assert(cls, string.format("ul.load() - package class \"%s\" load failed", packageName))
            loaded_packages[name] = cls

            if DEBUG > 1 then
                printInfo("ul.load() - load module \"packages.%s.init\"", name)
            end
        end
        packages[#packages + 1] = loaded_packages[name]
    end
    return unpack(packages)
end

local load_ = ul.load
local bind_
bind_ = function(target, ...)
    local t = type(target)
    assert(t == "table" or t == "userdata", string.format("ul.bind() - invalid target, expected is object, actual is %s", t))
    local names = {...}
    assert(#names > 0, "ul.bind() - package names expected")

    load_(...)
    if not target.components_ then target.components_ = {} end
    for _, name in ipairs(names) do
        assert(type(name) == "string" and name ~= "", string.format("ul.bind() - invalid package name \"%s\"", name))
        if not target.components_[name] then
            local cls = loaded_packages[name]
            for __, depend in ipairs(cls.depends or {}) do
                if not target.components_[depend] then
                    bind_(target, depend)
                end
            end
            local component = cls:create()
            target.components_[name] = component
            component:bind(target)
        end
    end

    return target
end
ul.bind = bind_

function ul.unbind(target, ...)
    if not target.components_ then return end

    local names = {...}
    assert(#names > 0, "ul.unbind() - invalid package names")

    for _, name in ipairs(names) do
        assert(type(name) == "string" and name ~= "", string.format("ul.unbind() - invalid package name \"%s\"", name))
        local component = target.components_[name]
        assert(component, string.format("ul.unbind() - component \"%s\" not found", tostring(name)))
        component:unbind(target)
        target.components_[name] = nil
    end
    return target
end

function ul.setmethods(target, component, methods)
    for _, name in ipairs(methods) do
        local method = component[name]
        target[name] = function(__, ...)
            return method(component, ...)
        end
    end
end

function ul.unsetmethods(target, methods)
    for _, name in ipairs(methods) do
        target[name] = nil
    end
end
