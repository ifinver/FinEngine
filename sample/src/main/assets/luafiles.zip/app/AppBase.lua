--
-- Author: Sowyer(e-mail:suyang@loveorange.com)
-- Date: 2016-12-02 15:37:09
--
local AppBase = class("AppBase")

function AppBase:ctor()
	math.randomseed(os.time()) -- randomseed

	app = self -- 全局app

	-- 事件通知
	ul.bind(self, "event")

	self._insObj = UnityEngine.GameObject("lua_insObj") -- 全局存在的GameObject，负责如查找等功能，由app维护
	self._insObj.DontDestroyOnLoad(self._insObj)
end

function AppBase:run()
end

-- 查找Object
function AppBase:find( objName )
	if type(objName) ~= "string" then return nil end

	return self._insObj.Find(objName)
end

function AppBase:findGameObjectsWithTag(tag)
	return self._insObj.FindGameObjectsWithTag(tag)
end

function AppBase:scheduleUpdate(update)
	if (not update) or type(update) ~= "function" then return end

	-- Update
	UpdateBeat:Add(function(sender)
		update(self, sender)
	end, self)
end

return AppBase