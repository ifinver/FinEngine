local Sphere = class("Sphere", require("app.AppBase"))

function Sphere:ctor(gameObject)
{
    self.super.ctor(self)

    print("==== im a sphere ====")
}

return Sphere