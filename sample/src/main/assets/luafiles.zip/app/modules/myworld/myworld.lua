local myworld = class("myworld", require("app.AppBase"))
function myworld:ctor(gameObject)

    self.super.ctor(self)

    -- gameObject:SetActive(false)
    -- self:scheduleUpdate(function()
      
    -- end)

    -- local role = self:find("role")
    -- role:SetActive(true)
    -- local roleCls = require("app.modules.myworld.role")
    -- local roleTest = roleCls.new(role)
    -- local tb = {1,2,3,4,5,6}
    -- local tb2 = 
    -- {
    --     ["abc"] = 123,
    --     [1], = "fdsfd", 
    --     [5] = "abc",
    --     [10] = "sss"
    -- }
    
    -- for k, v in pairs(tb) do
    --     print(k, v)
    -- end

    -- for i, v in ipairs(tb) do
    --     print(i, v)
    -- end

    -- local plan = self:find("land")
    -- plan.transform:Rotate(Vector3(0, 45, 0))
    -- local rb = gameObject:GetComponent(typeof(UnityEngine.Rigidbody))
    -- rb.useGravity = false
    -- print(rb.name)
    -- local animator = gameObject:GetComponent(typeof(UnityEngine.Animator))
    -- local audio = gameObject:GetComponent(typeof(UnityEngine.AudioSource))
    
    self:scheduleUpdate(function()
     print("-------1111111111------")
    -- if UnityEngine.Input.touchCount > 0 and UnityEngine.Input.GetTouch(0).phase == UnityEngine.TouchPhase.Began then
    --     -- local plan = self:find("land")
    --     -- local plan = gameObject.transform:FindChild("land")
    --     -- plan.transform:Rotate(Vector3(0, 45, 0))
        -- local assetloader = self:find("xiongtest")
        
        -- animator:SetTrigger("touch")
        -- audio:Play()
        -- print("-------23232------")
    -- end  
    end)
end 

function Stopluascript()
	coroutine.stop(myworld)
end

return myworld