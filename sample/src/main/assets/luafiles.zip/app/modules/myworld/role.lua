local role = class("role", require("app.AppBase"))

function role:ctor(ga)

    self.super.ctor(self)
    -- local go = UnityEngine.GameObject('go', typeof(UnityEngine.Camera))
    -- gameObject:SetActive(false)
    -- gameObject.transform:Translate(Vector3(1,1,1))

    local animator = ga:GetComponent(typeof(UnityEngine.Animator))
    local audio = ga:GetComponent(typeof(UnityEngine.AudioSource))

end 

return role