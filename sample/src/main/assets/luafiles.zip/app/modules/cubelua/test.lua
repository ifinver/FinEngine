--
-- Author: Sowyer(e-mail:suyang@loveorange.com)
-- Date: 2016-12-05 15:18:47
--
local Test = class("Test", require("app.AppBase"))

function Test:ctor(gameObject)
	self.super.ctor(self)

	self._gameObject = gameObject

	print("======== im test =================")
	print("======== im test =================")
	print("======== im test =================")
	print("======== im test =================")
	print("======== im test =================")

	gameObject:SetActive(false)

	-- self:scheduleUpdate(function()
	-- 	gameObject.transform.rotation = Vector3.up * UnityEngine.Time.time * 10
	-- 	print("======== im test =================")

	-- end)

	

end

return Test