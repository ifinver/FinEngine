--
-- Author: Sowyer(e-mail:suyang@loveorange.com)
-- Date: 2016-12-05 15:18:47
--
local Videocontroller = class("Videocontroller", require("app.AppBase"))

function Videocontroller:ctor(gameObject)
	self.super.ctor(self)

	self._gameObject = gameObject

	self:scheduleUpdate(function()
		if Input.GetTouch(0).phase == TouchPhase.Begin then
			print("===== ==== === === ")
		end
	end)
end

return Videocontroller